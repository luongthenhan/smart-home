app.directive("deviceScriptWhenThen", function() {
    return {
        restrict: "E",
        scope: {},
        templateUrl: "app/shared/device-script-when-then/deviceScriptWhenThenView.html"
    }
})
